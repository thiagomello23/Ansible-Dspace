export class Filter {

  key: string;
  tooltipKey: string;

  constructor(public id: string, public hasTooltip: boolean = false) {}

}
